import * as react from 'react';
import { PropsWithChildren, ReactNode } from 'react';
import * as _reduxjs_toolkit from '@reduxjs/toolkit';
import { Reducer, UnknownAction } from '@reduxjs/toolkit';
import { Resource, i18n } from 'i18next';

var nav$1 = {
	features: "Features",
	start: "Get started",
	extend: "Extend",
	docs: "Docs",
	demo: "View demo"
};
var hero$1 = {
	badge: "v0.1.4 — now available",
	before: "Build your ",
	product: "product",
	after: ", not the plumbing.",
	description: "Next.js, Redux, i18n, and Tailwind CSS—initialized and ready, with a complete admin UI. Focus only on what makes your product unique.",
	quickStart: "Quick start",
	proofStrong: "Set up in 30 seconds",
	proof: "Start building immediately"
};
var common$1 = {
	workspace: "Workspace",
	dashboard: "Dashboard",
	settings: "Settings",
	users: "Users",
	content: "Content",
	help: "Help",
	administrator: "Administrator",
	posts: "Posts",
	"new": "Create new",
	save: "Save changes",
	language: "Language"
};
var dashboard$1 = {
	welcome: "Welcome back, {{name}}",
	today: "Here’s what’s happening today.",
	totalUsers: "Total users",
	publishedContent: "Published content",
	monthlyViews: "Monthly views",
	conversion: "Conversion",
	compared: "vs last month",
	activity: "Activity",
	lastSevenDays: "Overview of the last 7 days",
	setupComplete: "Setup complete",
	setupReady: "Everything is ready"
};
var features$1 = {
	kicker: "EVERYTHING INCLUDED",
	title: "Everything you need, already included.",
	description: "Leave the repetitive setup to one-public-ui and spend your time on the features only you can build.",
	zeroTitle: "Zero config",
	zeroText: "Redux, i18n, and Tailwind CSS are ready. Add one Provider and start building.",
	adminTitle: "Admin included",
	adminText: "Login, dashboard, and settings screens come ready to use.",
	extendTitle: "Freely extensible",
	extendText: "Add your own screens, reducers, and translations without constraints."
};
var extend$1 = {
	kicker: "BUILT TO EXTEND",
	title: "Add your features naturally.",
	description: "Layer your screens, state, and translations on top of the provided foundation.",
	reducer: "Merge custom reducers into the store",
	messages: "Add or override Japanese and English messages",
	nav: "Add custom screens to the sidebar"
};
var cta$1 = {
	kicker: "START BUILDING TODAY",
	title: "Start your next product today.",
	description: "Install, initialize, and write your unique features.",
	login: "View login screen"
};
var settingsScreen$1 = {
	title: "Settings",
	description: "Manage your workspace and account.",
	general: "General",
	profile: "Profile",
	notifications: "Notifications",
	security: "Security",
	generalTitle: "General settings",
	generalDescription: "Basic workspace information",
	workspaceName: "Workspace name",
	timezone: "Timezone"
};
var login$1 = {
	kicker: "WELCOME BACK",
	title: "Sign in",
	description: "Access the admin console.",
	email: "Email",
	password: "Password",
	submit: "Sign in",
	foundation: "The foundation is ready.",
	value: "Build the next piece of value."
};
var posts$1 = {
	title: "Posts",
	description: "An example screen freely added by the consuming project.",
	create: "New post",
	list: "Post list",
	published: "Published"
};
var en = {
	nav: nav$1,
	hero: hero$1,
	common: common$1,
	dashboard: dashboard$1,
	features: features$1,
	extend: extend$1,
	cta: cta$1,
	settingsScreen: settingsScreen$1,
	login: login$1,
	posts: posts$1
};

var nav = {
	features: "機能",
	start: "はじめる",
	extend: "拡張する",
	docs: "ドキュメント",
	demo: "デモを見る"
};
var hero = {
	badge: "v0.1.4 — 利用可能",
	before: "共通基盤ではなく、",
	product: "プロダクト",
	after: "を作ろう。",
	description: "Next.js、Redux、i18n、Tailwind CSS。面倒な初期化も、管理画面も、全部ひとつに。あなたは独自機能だけに集中できます。",
	quickStart: "クイックスタート",
	proofStrong: "導入はたった30秒",
	proof: "すぐに開発を始められます"
};
var common = {
	workspace: "ワークスペース",
	dashboard: "ダッシュボード",
	settings: "設定",
	users: "ユーザー",
	content: "コンテンツ",
	help: "ヘルプ",
	administrator: "管理者",
	posts: "投稿管理",
	"new": "新規作成",
	save: "変更を保存",
	language: "言語"
};
var dashboard = {
	welcome: "おかえりなさい、{{name}}さん",
	today: "今日の状況を確認しましょう。",
	totalUsers: "総ユーザー数",
	publishedContent: "公開コンテンツ",
	monthlyViews: "今月のPV",
	conversion: "コンバージョン",
	compared: "先月比",
	activity: "アクティビティ",
	lastSevenDays: "過去7日間の概要",
	setupComplete: "セットアップ完了",
	setupReady: "すべての準備が整いました"
};
var features = {
	kicker: "必要なものをすべて同梱",
	title: "必要なものは、すべて揃っています。",
	description: "繰り返しの初期設定はone-public-uiに任せて、あなたにしか作れない機能に時間を使ってください。",
	zeroTitle: "ゼロコンフィグ",
	zeroText: "Redux、i18n、Tailwind CSSは設定済み。Providerを1つ置くだけで開始できます。",
	adminTitle: "管理画面つき",
	adminText: "ログイン、ダッシュボード、設定画面を標準搭載。すぐに使える美しいUIです。",
	extendTitle: "自由に拡張",
	extendText: "独自画面、Reducer、翻訳メッセージを追加可能。制約のない設計です。"
};
var extend = {
	kicker: "拡張を前提に設計",
	title: "あなたの機能を、自然に追加。",
	description: "提供される基盤の上に、独自の画面や状態管理、翻訳をそのまま積み重ねられます。",
	reducer: "独自Reducerをストアに統合",
	messages: "日本語・英語メッセージを上書き・追加",
	nav: "サイドバーへ独自画面を追加"
};
var cta = {
	kicker: "今日から始めよう",
	title: "次のプロダクトを、今日から。",
	description: "インストールして、初期化して、独自機能を書くだけ。",
	login: "ログイン画面を見る"
};
var settingsScreen = {
	title: "設定",
	description: "ワークスペースとアカウントの設定を管理します。",
	general: "一般",
	profile: "プロフィール",
	notifications: "通知",
	security: "セキュリティ",
	generalTitle: "一般設定",
	generalDescription: "ワークスペースの基本情報",
	workspaceName: "ワークスペース名",
	timezone: "タイムゾーン"
};
var login = {
	kicker: "おかえりなさい",
	title: "ログイン",
	description: "管理画面へアクセスします。",
	email: "メールアドレス",
	password: "パスワード",
	submit: "ログイン",
	foundation: "基盤はもう、できている。",
	value: "あなたは次の価値を作るだけ。"
};
var posts = {
	title: "投稿管理",
	description: "これは利用プロジェクト側が自由に追加した画面の例です。",
	create: "新しい投稿",
	list: "投稿一覧",
	published: "公開済み"
};
var ja = {
	nav: nav,
	hero: hero,
	common: common,
	dashboard: dashboard,
	features: features,
	extend: extend,
	cta: cta,
	settingsScreen: settingsScreen,
	login: login,
	posts: posts
};

type ReducerMap = Record<string, Reducer<unknown, UnknownAction>>;
declare function createOnePublicUIStore(extraReducers?: ReducerMap, preloadedState?: Record<string, unknown>): _reduxjs_toolkit.EnhancedStore<{
    onePublicUI: {
        sidebarOpen: boolean;
        theme: string;
        locale: string;
    };
}, UnknownAction, _reduxjs_toolkit.Tuple<[_reduxjs_toolkit.StoreEnhancer<{
    dispatch: _reduxjs_toolkit.ThunkDispatch<{
        onePublicUI: {
            sidebarOpen: boolean;
            theme: string;
            locale: string;
        };
    }, undefined, UnknownAction>;
}>, _reduxjs_toolkit.StoreEnhancer]>>;

declare const defaultMessages: Resource;
declare function createOnePublicUII18n(resources?: Resource): i18n;
type OnePublicUIProviderProps = PropsWithChildren<{
    reducers?: ReducerMap;
    messages?: Resource;
    preloadedState?: Record<string, unknown>;
    locale?: string;
}>;
declare function OnePublicUIProvider({ children, reducers, messages, preloadedState, locale }: OnePublicUIProviderProps): react.JSX.Element;

declare function ProductSite(): react.JSX.Element;

type AdminNavItem = {
    label?: string;
    labelKey?: string;
    href: string;
    icon?: ReactNode;
};
declare function normalizeAdminBasePath(value?: string): string;
declare function resolveAdminHref(href: string, adminBasePath?: string): string;
type AdminShellProps = PropsWithChildren<{
    navItems?: AdminNavItem[];
    adminBasePath?: string;
}>;
declare function AdminShell({ children, navItems, adminBasePath }: AdminShellProps): react.JSX.Element;

type AdminScreenProps = {
    navItems?: AdminNavItem[];
    adminBasePath?: string;
};
declare function DashboardScreen({ navItems, adminBasePath }: AdminScreenProps): react.JSX.Element;

export { type AdminNavItem, AdminShell, type AdminShellProps, DashboardScreen, OnePublicUIProvider, type OnePublicUIProviderProps, ProductSite, type ReducerMap, createOnePublicUII18n, createOnePublicUIStore, defaultMessages, en as enMessages, ja as jaMessages, normalizeAdminBasePath, resolveAdminHref };
