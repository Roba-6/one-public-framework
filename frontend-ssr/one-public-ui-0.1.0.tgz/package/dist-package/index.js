"use client";
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var index_exports = {};
__export(index_exports, {
  AdminShell: () => AdminShell,
  DashboardScreen: () => DashboardScreen,
  OnePublicUIProvider: () => OnePublicUIProvider,
  ProductSite: () => ProductSite,
  createOnePublicUII18n: () => createOnePublicUII18n,
  createOnePublicUIStore: () => createOnePublicUIStore,
  defaultMessages: () => defaultMessages,
  enMessages: () => en_default,
  jaMessages: () => ja_default,
  normalizeAdminBasePath: () => normalizeAdminBasePath,
  resolveAdminHref: () => resolveAdminHref
});
module.exports = __toCommonJS(index_exports);

// src/core.tsx
var import_toolkit = require("@reduxjs/toolkit");
var import_i18next = __toESM(require("i18next"));
var import_react_i18next = require("react-i18next");
var import_react_redux = require("react-redux");
var import_react = require("react");

// src/locales/en.json
var en_default = {
  nav: {
    features: "Features",
    start: "Get started",
    extend: "Extend",
    docs: "Docs",
    demo: "View demo"
  },
  hero: {
    badge: "v0.1.4 \u2014 now available",
    before: "Build your ",
    product: "product",
    after: ", not the plumbing.",
    description: "Next.js, Redux, i18n, and Tailwind CSS\u2014initialized and ready, with a complete admin UI. Focus only on what makes your product unique.",
    quickStart: "Quick start",
    proofStrong: "Set up in 30 seconds",
    proof: "Start building immediately"
  },
  common: {
    workspace: "Workspace",
    dashboard: "Dashboard",
    settings: "Settings",
    users: "Users",
    content: "Content",
    help: "Help",
    administrator: "Administrator",
    posts: "Posts",
    new: "Create new",
    save: "Save changes",
    language: "Language"
  },
  dashboard: {
    welcome: "Welcome back, {{name}}",
    today: "Here\u2019s what\u2019s happening today.",
    totalUsers: "Total users",
    publishedContent: "Published content",
    monthlyViews: "Monthly views",
    conversion: "Conversion",
    compared: "vs last month",
    activity: "Activity",
    lastSevenDays: "Overview of the last 7 days",
    setupComplete: "Setup complete",
    setupReady: "Everything is ready"
  },
  features: {
    kicker: "EVERYTHING INCLUDED",
    title: "Everything you need, already included.",
    description: "Leave the repetitive setup to one-public-ui and spend your time on the features only you can build.",
    zeroTitle: "Zero config",
    zeroText: "Redux, i18n, and Tailwind CSS are ready. Add one Provider and start building.",
    adminTitle: "Admin included",
    adminText: "Login, dashboard, and settings screens come ready to use.",
    extendTitle: "Freely extensible",
    extendText: "Add your own screens, reducers, and translations without constraints."
  },
  extend: {
    kicker: "BUILT TO EXTEND",
    title: "Add your features naturally.",
    description: "Layer your screens, state, and translations on top of the provided foundation.",
    reducer: "Merge custom reducers into the store",
    messages: "Add or override Japanese and English messages",
    nav: "Add custom screens to the sidebar"
  },
  cta: {
    kicker: "START BUILDING TODAY",
    title: "Start your next product today.",
    description: "Install, initialize, and write your unique features.",
    login: "View login screen"
  },
  settingsScreen: {
    title: "Settings",
    description: "Manage your workspace and account.",
    general: "General",
    profile: "Profile",
    notifications: "Notifications",
    security: "Security",
    generalTitle: "General settings",
    generalDescription: "Basic workspace information",
    workspaceName: "Workspace name",
    timezone: "Timezone"
  },
  login: {
    kicker: "WELCOME BACK",
    title: "Sign in",
    description: "Access the admin console.",
    email: "Email",
    password: "Password",
    submit: "Sign in",
    foundation: "The foundation is ready.",
    value: "Build the next piece of value."
  },
  posts: {
    title: "Posts",
    description: "An example screen freely added by the consuming project.",
    create: "New post",
    list: "Post list",
    published: "Published"
  }
};

// src/locales/ja.json
var ja_default = {
  nav: {
    features: "\u6A5F\u80FD",
    start: "\u306F\u3058\u3081\u308B",
    extend: "\u62E1\u5F35\u3059\u308B",
    docs: "\u30C9\u30AD\u30E5\u30E1\u30F3\u30C8",
    demo: "\u30C7\u30E2\u3092\u898B\u308B"
  },
  hero: {
    badge: "v0.1.4 \u2014 \u5229\u7528\u53EF\u80FD",
    before: "\u5171\u901A\u57FA\u76E4\u3067\u306F\u306A\u304F\u3001",
    product: "\u30D7\u30ED\u30C0\u30AF\u30C8",
    after: "\u3092\u4F5C\u308D\u3046\u3002",
    description: "Next.js\u3001Redux\u3001i18n\u3001Tailwind CSS\u3002\u9762\u5012\u306A\u521D\u671F\u5316\u3082\u3001\u7BA1\u7406\u753B\u9762\u3082\u3001\u5168\u90E8\u3072\u3068\u3064\u306B\u3002\u3042\u306A\u305F\u306F\u72EC\u81EA\u6A5F\u80FD\u3060\u3051\u306B\u96C6\u4E2D\u3067\u304D\u307E\u3059\u3002",
    quickStart: "\u30AF\u30A4\u30C3\u30AF\u30B9\u30BF\u30FC\u30C8",
    proofStrong: "\u5C0E\u5165\u306F\u305F\u3063\u305F30\u79D2",
    proof: "\u3059\u3050\u306B\u958B\u767A\u3092\u59CB\u3081\u3089\u308C\u307E\u3059"
  },
  common: {
    workspace: "\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9",
    dashboard: "\u30C0\u30C3\u30B7\u30E5\u30DC\u30FC\u30C9",
    settings: "\u8A2D\u5B9A",
    users: "\u30E6\u30FC\u30B6\u30FC",
    content: "\u30B3\u30F3\u30C6\u30F3\u30C4",
    help: "\u30D8\u30EB\u30D7",
    administrator: "\u7BA1\u7406\u8005",
    posts: "\u6295\u7A3F\u7BA1\u7406",
    new: "\u65B0\u898F\u4F5C\u6210",
    save: "\u5909\u66F4\u3092\u4FDD\u5B58",
    language: "\u8A00\u8A9E"
  },
  dashboard: {
    welcome: "\u304A\u304B\u3048\u308A\u306A\u3055\u3044\u3001{{name}}\u3055\u3093",
    today: "\u4ECA\u65E5\u306E\u72B6\u6CC1\u3092\u78BA\u8A8D\u3057\u307E\u3057\u3087\u3046\u3002",
    totalUsers: "\u7DCF\u30E6\u30FC\u30B6\u30FC\u6570",
    publishedContent: "\u516C\u958B\u30B3\u30F3\u30C6\u30F3\u30C4",
    monthlyViews: "\u4ECA\u6708\u306EPV",
    conversion: "\u30B3\u30F3\u30D0\u30FC\u30B8\u30E7\u30F3",
    compared: "\u5148\u6708\u6BD4",
    activity: "\u30A2\u30AF\u30C6\u30A3\u30D3\u30C6\u30A3",
    lastSevenDays: "\u904E\u53BB7\u65E5\u9593\u306E\u6982\u8981",
    setupComplete: "\u30BB\u30C3\u30C8\u30A2\u30C3\u30D7\u5B8C\u4E86",
    setupReady: "\u3059\u3079\u3066\u306E\u6E96\u5099\u304C\u6574\u3044\u307E\u3057\u305F"
  },
  features: {
    kicker: "\u5FC5\u8981\u306A\u3082\u306E\u3092\u3059\u3079\u3066\u540C\u68B1",
    title: "\u5FC5\u8981\u306A\u3082\u306E\u306F\u3001\u3059\u3079\u3066\u63C3\u3063\u3066\u3044\u307E\u3059\u3002",
    description: "\u7E70\u308A\u8FD4\u3057\u306E\u521D\u671F\u8A2D\u5B9A\u306Fone-public-ui\u306B\u4EFB\u305B\u3066\u3001\u3042\u306A\u305F\u306B\u3057\u304B\u4F5C\u308C\u306A\u3044\u6A5F\u80FD\u306B\u6642\u9593\u3092\u4F7F\u3063\u3066\u304F\u3060\u3055\u3044\u3002",
    zeroTitle: "\u30BC\u30ED\u30B3\u30F3\u30D5\u30A3\u30B0",
    zeroText: "Redux\u3001i18n\u3001Tailwind CSS\u306F\u8A2D\u5B9A\u6E08\u307F\u3002Provider\u30921\u3064\u7F6E\u304F\u3060\u3051\u3067\u958B\u59CB\u3067\u304D\u307E\u3059\u3002",
    adminTitle: "\u7BA1\u7406\u753B\u9762\u3064\u304D",
    adminText: "\u30ED\u30B0\u30A4\u30F3\u3001\u30C0\u30C3\u30B7\u30E5\u30DC\u30FC\u30C9\u3001\u8A2D\u5B9A\u753B\u9762\u3092\u6A19\u6E96\u642D\u8F09\u3002\u3059\u3050\u306B\u4F7F\u3048\u308B\u7F8E\u3057\u3044UI\u3067\u3059\u3002",
    extendTitle: "\u81EA\u7531\u306B\u62E1\u5F35",
    extendText: "\u72EC\u81EA\u753B\u9762\u3001Reducer\u3001\u7FFB\u8A33\u30E1\u30C3\u30BB\u30FC\u30B8\u3092\u8FFD\u52A0\u53EF\u80FD\u3002\u5236\u7D04\u306E\u306A\u3044\u8A2D\u8A08\u3067\u3059\u3002"
  },
  extend: {
    kicker: "\u62E1\u5F35\u3092\u524D\u63D0\u306B\u8A2D\u8A08",
    title: "\u3042\u306A\u305F\u306E\u6A5F\u80FD\u3092\u3001\u81EA\u7136\u306B\u8FFD\u52A0\u3002",
    description: "\u63D0\u4F9B\u3055\u308C\u308B\u57FA\u76E4\u306E\u4E0A\u306B\u3001\u72EC\u81EA\u306E\u753B\u9762\u3084\u72B6\u614B\u7BA1\u7406\u3001\u7FFB\u8A33\u3092\u305D\u306E\u307E\u307E\u7A4D\u307F\u91CD\u306D\u3089\u308C\u307E\u3059\u3002",
    reducer: "\u72EC\u81EAReducer\u3092\u30B9\u30C8\u30A2\u306B\u7D71\u5408",
    messages: "\u65E5\u672C\u8A9E\u30FB\u82F1\u8A9E\u30E1\u30C3\u30BB\u30FC\u30B8\u3092\u4E0A\u66F8\u304D\u30FB\u8FFD\u52A0",
    nav: "\u30B5\u30A4\u30C9\u30D0\u30FC\u3078\u72EC\u81EA\u753B\u9762\u3092\u8FFD\u52A0"
  },
  cta: {
    kicker: "\u4ECA\u65E5\u304B\u3089\u59CB\u3081\u3088\u3046",
    title: "\u6B21\u306E\u30D7\u30ED\u30C0\u30AF\u30C8\u3092\u3001\u4ECA\u65E5\u304B\u3089\u3002",
    description: "\u30A4\u30F3\u30B9\u30C8\u30FC\u30EB\u3057\u3066\u3001\u521D\u671F\u5316\u3057\u3066\u3001\u72EC\u81EA\u6A5F\u80FD\u3092\u66F8\u304F\u3060\u3051\u3002",
    login: "\u30ED\u30B0\u30A4\u30F3\u753B\u9762\u3092\u898B\u308B"
  },
  settingsScreen: {
    title: "\u8A2D\u5B9A",
    description: "\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9\u3068\u30A2\u30AB\u30A6\u30F3\u30C8\u306E\u8A2D\u5B9A\u3092\u7BA1\u7406\u3057\u307E\u3059\u3002",
    general: "\u4E00\u822C",
    profile: "\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB",
    notifications: "\u901A\u77E5",
    security: "\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3",
    generalTitle: "\u4E00\u822C\u8A2D\u5B9A",
    generalDescription: "\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9\u306E\u57FA\u672C\u60C5\u5831",
    workspaceName: "\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9\u540D",
    timezone: "\u30BF\u30A4\u30E0\u30BE\u30FC\u30F3"
  },
  login: {
    kicker: "\u304A\u304B\u3048\u308A\u306A\u3055\u3044",
    title: "\u30ED\u30B0\u30A4\u30F3",
    description: "\u7BA1\u7406\u753B\u9762\u3078\u30A2\u30AF\u30BB\u30B9\u3057\u307E\u3059\u3002",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    password: "\u30D1\u30B9\u30EF\u30FC\u30C9",
    submit: "\u30ED\u30B0\u30A4\u30F3",
    foundation: "\u57FA\u76E4\u306F\u3082\u3046\u3001\u3067\u304D\u3066\u3044\u308B\u3002",
    value: "\u3042\u306A\u305F\u306F\u6B21\u306E\u4FA1\u5024\u3092\u4F5C\u308B\u3060\u3051\u3002"
  },
  posts: {
    title: "\u6295\u7A3F\u7BA1\u7406",
    description: "\u3053\u308C\u306F\u5229\u7528\u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u5074\u304C\u81EA\u7531\u306B\u8FFD\u52A0\u3057\u305F\u753B\u9762\u306E\u4F8B\u3067\u3059\u3002",
    create: "\u65B0\u3057\u3044\u6295\u7A3F",
    list: "\u6295\u7A3F\u4E00\u89A7",
    published: "\u516C\u958B\u6E08\u307F"
  }
};

// src/core.tsx
var import_jsx_runtime = require("react/jsx-runtime");
var uiSlice = (0, import_toolkit.createSlice)({
  name: "onePublicUI",
  initialState: { sidebarOpen: true, theme: "light", locale: "ja" },
  reducers: {
    toggleSidebar: (state) => {
      state.sidebarOpen = !state.sidebarOpen;
    },
    setTheme: (state, action) => {
      state.theme = action.payload;
    },
    setLocale: (state, action) => {
      state.locale = action.payload;
    }
  }
});
function createOnePublicUIStore(extraReducers = {}, preloadedState) {
  return (0, import_toolkit.configureStore)({
    reducer: (0, import_toolkit.combineReducers)(__spreadValues({ onePublicUI: uiSlice.reducer }, extraReducers)),
    preloadedState
  });
}
var defaultMessages = {
  ja: { translation: ja_default },
  en: { translation: en_default }
};
function mergeMessageTree(base, custom) {
  const merged = __spreadValues({}, base);
  for (const [key, value] of Object.entries(custom)) {
    const baseValue = merged[key];
    merged[key] = value && typeof value === "object" && !Array.isArray(value) && baseValue && typeof baseValue === "object" && !Array.isArray(baseValue) ? mergeMessageTree(baseValue, value) : value;
  }
  return merged;
}
function createOnePublicUII18n(resources = {}) {
  var _a, _b, _c, _d;
  const instance = import_i18next.default.createInstance();
  const customJa = (_b = (_a = resources.ja) == null ? void 0 : _a.translation) != null ? _b : {};
  const customEn = (_d = (_c = resources.en) == null ? void 0 : _c.translation) != null ? _d : {};
  instance.use(import_react_i18next.initReactI18next).init({
    lng: "ja",
    fallbackLng: "en",
    resources: __spreadProps(__spreadValues({}, resources), {
      ja: { translation: mergeMessageTree(ja_default, customJa) },
      en: { translation: mergeMessageTree(en_default, customEn) }
    }),
    interpolation: { escapeValue: false }
  });
  return instance;
}
function OnePublicUIProvider({ children, reducers = {}, messages = {}, preloadedState, locale = "ja" }) {
  const store = (0, import_react.useMemo)(() => createOnePublicUIStore(reducers, preloadedState), [reducers, preloadedState]);
  const i18n = (0, import_react.useMemo)(() => {
    const instance = createOnePublicUII18n(messages);
    void instance.changeLanguage(locale);
    return instance;
  }, [messages, locale]);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react_redux.Provider, { store, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react_i18next.I18nextProvider, { i18n, children }) });
}

// src/product-site.tsx
var import_link = __toESM(require("next/link"));
var import_react2 = require("react");
var import_react_i18next2 = require("react-i18next");
var import_jsx_runtime2 = require("react/jsx-runtime");
var code = `import {
  OnePublicUIProvider,
  AdminShell
} from "one-public-ui";

const postsReducer = createSlice({
  name: "posts",
  initialState: []
}).reducer;

export default function Layout({ children }) {
  return (
    <OnePublicUIProvider
      reducers={{ posts: postsReducer }}
      messages={customMessages}
    >
      <AdminShell navItems={[
        { label: "\u6295\u7A3F\u7BA1\u7406", href: "/admin/posts" }
      ]}>
        {children}
      </AdminShell>
    </OnePublicUIProvider>
  );
}`;
function ProductSite() {
  const { t, i18n } = (0, import_react_i18next2.useTranslation)();
  const [copied, setCopied] = (0, import_react2.useState)(false);
  const copyInstall = async () => {
    var _a;
    await ((_a = navigator.clipboard) == null ? void 0 : _a.writeText("npm install one-public-ui"));
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-site", children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("nav", { className: "opu-topnav", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_link.default, { href: "/", className: "opu-brand", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "one" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "public ui" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-navlinks", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("a", { href: "#features", children: t("nav.features") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("a", { href: "#start", children: t("nav.start") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("a", { href: "#extend", children: t("nav.extend") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("a", { href: "#docs", children: t("nav.docs") })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { className: "opu-locale", onClick: () => void i18n.changeLanguage(i18n.resolvedLanguage === "ja" ? "en" : "ja"), children: i18n.resolvedLanguage === "ja" ? "EN" : "JA" }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_link.default, { className: "opu-nav-cta", href: "/admin/dashboard", children: [
        t("nav.demo"),
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\u2197" })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("main", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "opu-hero", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-eyebrow", children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\u25CF" }),
          " ",
          t("hero.badge")
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("h1", { children: [
          t("hero.before"),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("br", {}),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("em", { children: t("hero.product") }),
          t("hero.after")
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: t("hero.description") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-hero-actions", children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("button", { onClick: copyInstall, className: "opu-install", children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("code", { children: "$ npm install one-public-ui" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: copied ? "\u2713" : "\u29C9" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("a", { href: "#start", className: "opu-start", children: [
            t("hero.quickStart"),
            " ",
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\u2192" })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-proof", children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "opu-avatars", children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("i", { children: "YU" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("i", { children: "KM" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("i", { children: "AN" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("i", { children: "+" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: t("hero.proofStrong") }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: t("hero.proof") })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "opu-preview-wrap", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-browser", children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-browserbar", children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "opu-dots", children: "\u25CF \u25CF \u25CF" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "opu-url", children: "\u25A3\u3000localhost:3000/admin/dashboard" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\u2304" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-browserbody", children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("aside", { className: "opu-demo-side", children: [
              /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "one public ui" }),
              /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("small", { children: t("common.workspace") }),
              /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "sel", children: [
                "\u2302\u3000",
                t("common.dashboard")
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { children: [
                "\u25A4\u3000",
                t("common.users")
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { children: [
                "\u25A1\u3000",
                t("common.content")
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { children: [
                "\u25C7\u3000",
                t("common.settings")
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { children: [
                "\u25C9\u3000",
                t("common.help")
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-demo-user", children: [
                /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("i", { children: "RN" }),
                /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("b", { children: [
                  "Rina Nakamura",
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("small", { children: t("common.administrator") })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-demo-main", children: [
              /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-demo-top", children: [
                "\u2315\u3000\u2662\u3000",
                /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "RN" })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-demo-content", children: [
                /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-demo-title", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h3", { children: t("dashboard.welcome", { name: "Rina" }) }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: t("dashboard.today") })
                  ] }),
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("button", { children: [
                    "\uFF0B ",
                    t("common.new")
                  ] })
                ] }),
                /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-stats", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("article", { children: [
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { children: [
                      t("dashboard.totalUsers"),
                      "\u3000\u2197"
                    ] }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "2,543" }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("small", { children: [
                      "+12.5%\u3000",
                      t("dashboard.compared")
                    ] })
                  ] }),
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("article", { children: [
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { children: [
                      t("dashboard.publishedContent"),
                      "\u3000\u25EB"
                    ] }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "186" }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("small", { children: [
                      "+8.2%\u3000",
                      t("dashboard.compared")
                    ] })
                  ] }),
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("article", { children: [
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { children: [
                      t("dashboard.monthlyViews"),
                      "\u3000\u2301"
                    ] }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "48.2K" }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("small", { children: [
                      "+24.3%\u3000",
                      t("dashboard.compared")
                    ] })
                  ] }),
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("article", { children: [
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { children: [
                      t("dashboard.conversion"),
                      "\u3000\u2197"
                    ] }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "3.8%" }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("small", { children: [
                      "+0.4%\u3000",
                      t("dashboard.compared")
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-chart", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: t("dashboard.activity") }),
                    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("small", { children: t("dashboard.lastSevenDays") })
                  ] }),
                  /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "opu-bars", children: [45, 59, 47, 72, 62, 88, 78, 94, 65, 80, 75, 96].map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("i", { style: { height: `${h}%` } }, i)) })
                ] })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-floating-card", children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\u2713" }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: t("dashboard.setupComplete") }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("small", { children: t("dashboard.setupReady") })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { id: "features", className: "opu-feature-intro", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "opu-section-kicker", children: t("features.kicker") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: t("features.title") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: t("features.description") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-feature-grid", children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("article", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\u26A1" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h3", { children: t("features.zeroTitle") }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: t("features.zeroText") })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("article", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\u25A6" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h3", { children: t("features.adminTitle") }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: t("features.adminText") })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("article", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\uFF0B" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h3", { children: t("features.extendTitle") }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: t("features.extendText") })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { id: "extend", className: "opu-code-section", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "opu-section-kicker", children: t("extend.kicker") }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: t("extend.title") }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: t("extend.description") }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("ul", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("li", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "\u2713" }),
              " ",
              t("extend.reducer")
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("li", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "\u2713" }),
              " ",
              t("extend.messages")
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("li", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "\u2713" }),
              " ",
              t("extend.nav")
            ] })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "opu-code-card", children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "app/layout.tsx" }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "\u25CF \u25CF \u25CF" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("pre", { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("code", { children: code }) })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { id: "start", className: "opu-cta", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "opu-section-kicker", children: t("cta.kicker") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: t("cta.title") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: t("cta.description") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("button", { onClick: copyInstall, className: "opu-install light", children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("code", { children: "$ npm install one-public-ui" }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: copied ? "\u2713" : "\u29C9" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_link.default, { href: "/admin/login", children: [
          t("cta.login"),
          " \u2192"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("footer", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_link.default, { href: "/", className: "opu-brand", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "one" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("b", { children: "public ui" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "MIT License \xB7 Built for product teams." })
    ] })
  ] });
}

// src/admin-shell.tsx
var import_link2 = __toESM(require("next/link"));
var import_react_i18next3 = require("react-i18next");
var import_jsx_runtime3 = require("react/jsx-runtime");
function normalizeAdminBasePath(value = "/admin") {
  const trimmed = value.trim();
  const withLeadingSlash = trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
  return withLeadingSlash.replace(/\/+$/, "") || "/admin";
}
function resolveAdminHref(href, adminBasePath = "/admin") {
  const base = normalizeAdminBasePath(adminBasePath);
  return href === "/admin" || href.startsWith("/admin/") ? `${base}${href.slice("/admin".length)}` : href;
}
function AdminShell({ children, navItems = [], adminBasePath = "/admin" }) {
  const { t, i18n } = (0, import_react_i18next3.useTranslation)();
  const baseItems = [
    { labelKey: "common.dashboard", href: "/admin/dashboard" },
    { labelKey: "common.settings", href: "/admin/settings" }
  ];
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "opu-admin", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("aside", { className: "opu-sidebar", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_link2.default, { href: "/", className: "opu-brand", children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { children: "one" }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("b", { children: "public ui" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("p", { className: "opu-side-label", children: t("common.workspace") }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("nav", { children: [...baseItems, ...navItems].map((item, index) => {
        var _a;
        return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_link2.default, { href: resolveAdminHref(item.href, adminBasePath), className: `opu-nav-item ${index === 0 ? "active" : ""}`, children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "opu-nav-icon", children: (_a = item.icon) != null ? _a : index === 0 ? "\u2302" : "\u25C7" }),
          item.labelKey ? t(item.labelKey) : item.label
        ] }, item.href);
      }) }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "opu-side-user", children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "opu-avatar", children: "RN" }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("b", { children: "Rina Nakamura" }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("small", { children: t("common.administrator") })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { children: "\u2022\u2022\u2022" })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("main", { className: "opu-main", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("header", { className: "opu-admin-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "opu-mobile-brand", children: "one public ui" }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { className: "opu-header-actions", children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { className: "opu-locale", onClick: () => void i18n.changeLanguage(i18n.resolvedLanguage === "ja" ? "en" : "ja"), children: i18n.resolvedLanguage === "ja" ? "EN" : "JA" }),
          "\u3000\u2315\u3000\u2662\u3000",
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "opu-mini-avatar", children: "RN" })
        ] })
      ] }),
      children
    ] })
  ] });
}

// src/screens.tsx
var import_react_i18next4 = require("react-i18next");
var import_jsx_runtime4 = require("react/jsx-runtime");
var stats = [
  ["dashboard.totalUsers", "2,543"],
  ["dashboard.publishedContent", "186"],
  ["dashboard.monthlyViews", "48.2K"],
  ["dashboard.conversion", "3.8%"]
];
function DashboardScreen({ navItems = [], adminBasePath = "/admin" }) {
  const { t } = (0, import_react_i18next4.useTranslation)();
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(AdminShell, { navItems, adminBasePath, children: /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "opu-page", children: [
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "opu-page-head", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("h1", { children: t("dashboard.welcome", { name: "Rina" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { children: t("dashboard.today") })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("button", { className: "opu-primary", children: [
        "\uFF0B ",
        t("common.new")
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "opu-page-stats", children: stats.map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "opu-panel", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { children: t(key) }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("b", { children: value }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("small", { style: { color: "#4a9a5e" }, children: [
        "\u2197 12.5% ",
        t("dashboard.compared")
      ] })
    ] }, key)) }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "opu-panel", style: { marginTop: 18, height: 330 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("h3", { children: t("dashboard.activity") }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { children: t("dashboard.lastSevenDays") }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "opu-bars", style: { height: 220 }, children: [40, 65, 48, 73, 55, 88, 68, 93, 72, 83, 64, 96].map((height, index) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("i", { style: { height: `${height}%` } }, index)) })
    ] })
  ] }) });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AdminShell,
  DashboardScreen,
  OnePublicUIProvider,
  ProductSite,
  createOnePublicUII18n,
  createOnePublicUIStore,
  defaultMessages,
  enMessages,
  jaMessages,
  normalizeAdminBasePath,
  resolveAdminHref
});
//# sourceMappingURL=index.js.map